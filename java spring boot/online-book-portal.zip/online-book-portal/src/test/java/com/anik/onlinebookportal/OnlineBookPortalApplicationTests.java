package com.anik.onlinebookportal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineBookPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
