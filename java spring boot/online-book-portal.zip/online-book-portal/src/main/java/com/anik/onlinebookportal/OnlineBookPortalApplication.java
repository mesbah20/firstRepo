package com.anik.onlinebookportal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineBookPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineBookPortalApplication.class, args);
	}

}
